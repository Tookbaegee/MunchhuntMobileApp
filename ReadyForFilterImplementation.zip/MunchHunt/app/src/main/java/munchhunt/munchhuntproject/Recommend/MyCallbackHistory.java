package munchhunt.munchhuntproject.Recommend;

import java.util.ArrayList;

public interface MyCallbackHistory {
    void onCallback(ArrayList<String> history);


}
