package munchhunt.munchhuntproject.Callback;

import munchhunt.munchhuntproject.Objects.User;

public interface CurrentUserCallback {
    void callback(User currentUser);
}
