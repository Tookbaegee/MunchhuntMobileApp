package munchhunt.munchhuntproject.Party;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.List;

import munchhunt.munchhuntproject.R;
import munchhunt.munchhuntproject.Objects.User;

public class PartyWheelAdapter extends munchhunt.munchhuntproject.CursorWheelLayout.CycleWheelAdapter {

    private Context mContext;
    private List<User> userList;
    private LayoutInflater inflater;
    private int gravity;

    public PartyWheelAdapter(Context mContext, List<User> userList){
        this.mContext = mContext;
        this.userList = userList;
        gravity = Gravity.CENTER;
        inflater = LayoutInflater.from(mContext);
    }

    public PartyWheelAdapter(Context mContext, List<User> userList, int gravity){
        this.mContext = mContext;
        this.userList = userList;
        this.gravity = gravity;
    }

    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public View getView(View parent, int position) {
        User mUser = getItem(position);
        View root = inflater.inflate(R.layout.party_userbubble_adapter, null, false);
        TextView tvName = root.findViewById(R.id.usersname);
        tvName.setText(mUser.getName());
        if(tvName.getLayoutParams() instanceof FrameLayout.LayoutParams)
            ((FrameLayout.LayoutParams)tvName.getLayoutParams()).gravity = gravity;

        return root;
    }

    @Override
    public User getItem(int position) {
        return userList.get(position);
    }
}
