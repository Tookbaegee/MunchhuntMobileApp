package munchhunt.munchhuntproject.Callback;

import java.util.List;

import munchhunt.munchhuntproject.Objects.Request;

public interface RequestsCallback {
    void callback(List<Request> requests);
}
