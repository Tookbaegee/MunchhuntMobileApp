package munchhunt.munchhuntproject.Callback;

public interface PartyCallback<Party>{
    void callback(Party party);
}