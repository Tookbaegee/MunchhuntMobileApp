package munchhunt.munchhuntproject.Callback;

import java.util.List;

import munchhunt.munchhuntproject.Objects.DietPattern;

public interface DietPatternListCallback {
    void dietPatternListCallback(List<DietPattern> dietPatternList);
}
