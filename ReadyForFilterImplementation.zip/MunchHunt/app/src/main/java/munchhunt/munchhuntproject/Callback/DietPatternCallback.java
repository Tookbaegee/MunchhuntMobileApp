package munchhunt.munchhuntproject.Callback;

import munchhunt.munchhuntproject.Objects.DietPattern;

public interface DietPatternCallback {
    void dietPatternCallback(DietPattern dietPattern);
}
