//package munchhunt.munchhuntproject.Feed;
//
//public class Status {
//
//    private String date;
//    private String message;
//    private String userPic;
//    private String name;
//
//    public Status(String date, String message, String userPic, String name){
//        this.date = date;
//        this.message = message;
//        this.userPic = userPic;
//        this.name = name;
//    }
//
//    public String getDate() { return date; }
//
//    public String getMessage() { return message; }
//
//    public String getUserPic() { return userPic; }
//
//    public String getName() { return name; }
//
//    public void setName(String name) { this.name = name; }
//
//    public void setDate(String date) { this.date = date; }
//
//    public void setMessage(String message) { this.message = message; }
//
//    public void setUserPic(String userPic) { this.userPic = userPic; }
//
//
//}
