package munchhunt.munchhuntproject.Callback;

public interface CurrentUserIDCallback {
    void callback(String currentUserID);
}
