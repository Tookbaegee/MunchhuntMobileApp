package munchhunt.munchhuntproject.Callback;

public interface StringCallback {
    void callback(String stringToCallback);
}
