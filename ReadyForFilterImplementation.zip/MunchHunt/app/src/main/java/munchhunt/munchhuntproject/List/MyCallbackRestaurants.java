package munchhunt.munchhuntproject.List;

import java.util.ArrayList;

/**
 * Created by adria on 7/1/2018.
 */

public interface MyCallbackRestaurants {
        void onCallback(ArrayList<Menu> value);
}
