package munchhunt.munchhuntproject.Map;

import java.util.ArrayList;

import munchhunt.munchhuntproject.List.YelpBusinessInfo;

public interface MyCallbackRecommend {
    void onCallback(ArrayList<YelpBusinessInfo> value);

}
