package munchhunt.munchhuntproject.Callback;



public interface BooleanCallback {
    void callback(boolean data);
}