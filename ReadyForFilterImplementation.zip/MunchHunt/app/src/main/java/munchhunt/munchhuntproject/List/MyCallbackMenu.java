package munchhunt.munchhuntproject.List;

import java.util.ArrayList;

/**
 * Created by adria on 7/1/2018.
 */

public interface MyCallbackMenu {
    void onCallback(ArrayList<Menu> menu);
}
