package munchhunt.munchhuntproject.Callback;

import java.util.List;

import munchhunt.munchhuntproject.Objects.User;

/**
 * Created by kyl3g on 10/15/2018.
 */

public interface UserListCallback {
    void usersListCallback(List<User> users);
}
