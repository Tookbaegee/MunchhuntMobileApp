package munchhunt.munchhuntproject.Map;

import java.util.ArrayList;

import munchhunt.munchhuntproject.Objects.Restaurant;

public interface RestaurantDataCallback {

    void onCallback(ArrayList<Restaurant> restaurantList);

}
