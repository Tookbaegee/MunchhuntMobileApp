package munchhunt.munchhuntproject.DeprecatedClasses;

/**
 * Created by kyl3g on 9/21/2018.
 */

public class StateVO {
    private String title;
    private boolean selected;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}