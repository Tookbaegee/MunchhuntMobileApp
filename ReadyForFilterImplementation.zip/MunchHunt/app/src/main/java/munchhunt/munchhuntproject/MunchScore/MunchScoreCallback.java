package munchhunt.munchhuntproject.MunchScore;

public interface MunchScoreCallback {
    void onCallback(double munchScore);
}
