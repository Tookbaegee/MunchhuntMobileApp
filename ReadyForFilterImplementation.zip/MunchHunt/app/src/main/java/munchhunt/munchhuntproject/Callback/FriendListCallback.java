package munchhunt.munchhuntproject.Callback;

import java.util.List;

public interface FriendListCallback{
    void callback(List<String> friendsList);
}