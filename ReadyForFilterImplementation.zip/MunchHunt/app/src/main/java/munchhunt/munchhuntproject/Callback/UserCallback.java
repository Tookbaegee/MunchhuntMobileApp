package munchhunt.munchhuntproject.Callback;
public interface UserCallback<User> {
    void callback(User user);
}