package munchhunt.munchhuntproject.MunchScore;

import munchhunt.munchhuntproject.Objects.RestaurantItems;

public interface RestaurantItemsCallback {
    void onCallback(RestaurantItems restaurantList);

}
