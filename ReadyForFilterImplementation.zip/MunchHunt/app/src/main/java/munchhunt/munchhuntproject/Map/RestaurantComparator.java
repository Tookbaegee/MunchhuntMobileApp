package munchhunt.munchhuntproject.Map;

import java.util.Comparator;

import munchhunt.munchhuntproject.Objects.Restaurant;

public class RestaurantComparator implements Comparator<Restaurant> {
    @Override
    public int compare(Restaurant r1, Restaurant r2) {
        return (int) (r1.getMunchScore() - r2.getMunchScore())*1000000;
    }
}
